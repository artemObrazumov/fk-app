class Article {
    constructor (json){
    return Object.assign(this, json);
    }
}