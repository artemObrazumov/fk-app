class GameAction {
    constructor (json){
    return Object.assign(this, json);
    }
}