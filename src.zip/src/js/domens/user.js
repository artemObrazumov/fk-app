class User {
    constructor (json){
    return Object.assign(this, json);
    }
}