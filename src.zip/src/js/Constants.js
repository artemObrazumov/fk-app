const API_URL = "https://bfl8ob-83-220-239-61.ru.tuna.am"
const WEB_URL = "http://127.0.0.1:5500/src"